import 'package:flutter/material.dart';

BorderRadius borderAll = BorderRadius.circular(10);
